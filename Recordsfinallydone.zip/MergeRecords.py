from rec import *

def MergeRecords(blockSize,f1,f2,f3):
    '''
    Objective : To merge two sorted records one from f1 and one from f2 each of size 'blockSize'
                and write it to f3 in sorted manner
    Input:
         f1: File pointer for reading records from first file
         f2: File pointer for reading records from second file
         f3: File pointer for writing records to third file
    '''

    #MergeSort
    #print(blockSize,len(lst1),len(lst2))
    rec1 = None
    rec2 = None 
    last_loc1 = f1.tell()
    last_loc2 = f2.tell()
    i,j=0,0
    
    while i<blockSize and j<blockSize:
        last_loc1 = f1.tell()
        last_loc2 = f2.tell()
        try:
            rec1 = pickle.load(f1)
        except EOFError:
            i = blockSize
            break
        try:
            rec2 = pickle.load(f2)
        except EOFError:
            f1.seek(last_loc1)
            j = blockSize
            break
        
        if rec1.generatekey() < rec2.generatekey():
            pickle.dump(rec1,f3)
            f2.seek(last_loc2)
            i+=1
        else:
            pickle.dump(rec2,f3)
            f1.seek(last_loc1)
            j+=1

    while i<blockSize:
        try:
            pickle.dump(pickle.load(f1),f3)
            i+=1
        except EOFError:
            break

    while j<blockSize:
        try:
            pickle.dump(pickle.load(f2),f3)
            j+=1
        except EOFError:
            break
    


def mergeFile(Records1,Records2,n,blockSize):
    '''
    Objective: To merge files
    Input:
        nRecord : number of records
        blockSize: initial blockSize
    Return : None
    '''
    f3=open(Records3,'wb')
    f4=open(Records4,'wb')
    f1=open(Records1,'rb')
    f2=open(Records2,'rb')
    temp = 0
    blockSize=4

    #Merging records using mergesort until blocksize <= nRecord
    while n//blockSize:
        count = 0
        while count < n:
            MergeRecords(blockSize,f1,f2,f3)
            MergeRecords(blockSize,f1,f2,f4)
            count+=blockSize*4
        f1Name = f1.name
        f2Name = f2.name

        f1.close()
        f2.close()
        os.remove(f1Name)
        os.remove(f2Name)
        f3.close()
        f4.close()

        blockSize*=2        
        if temp == 0:
            f1 = open(Records3,'rb')
            f2 = open(Records4,'rb')
            f3 = open(Records1,'ab')
            f4 = open(Records2,'ab')
            temp = 1
        else:
            f1 = open(Records1,'rb')
            f2 = open(Records2,'rb')
            f3 = open(Records3,'ab')
            f4 = open(Records4,'ab')
            temp = 0

    if temp == 0:
        f1 = open(Records1,'rb')
        print("&&")
    else:
        f1 = open(Records3,'rb')

    lower= int(input('Enter the lower limit of record:'))
    upper= int(input('Enter the upper limit of record:'))
    if upper>n:
        print("Out of range")
        return

    pickle.load(f1)
    size = f1.tell()
    f1.seek(size*(lower))
    for i in range(lower,upper):
        try:
            print(pickle.load(f1))
        except:
            print("End of file.")
            break
if __name__=="__main__":
    Records1='Records1.txt'
    Records2='Records2.txt'
    Records3='Records3.txt'
    Records4='Records4.txt'
    mergeFile(Records1,Records2,n,blockSize)
