import pickle, os
import random
blockSize=4
n=100

class Record:
    '''
    Objective : To create an object of type 'Record'
    '''

    def __init__(self,key):
        '''
        Objective : To initialize an Record object
        Input     : self   : (Implicit) Record object
                    key    : key value of the object Record
                    others : value corresponding to that key
        Output    : None
        '''
        othersSize = 5
        self.key=key
        self.others= str(self.key)*othersSize
    
    def generatekey(self):
        '''Objective: to generate the key of record
        '''
        return self.key
    
    def __str__(self):
        '''
        Objective : To return a string of the values of the object Record
        Input     : self : (Implicit) Record object 
        OUTPUT    : a string representing the Record object
        '''

        return "Key: "+str(self.key) + "\nData: " +self.others


def Records(n):

    '''
    Objective : To write records in file1
    Input     : None 
    Output    : None 
    '''

    lst=list(range(1000000,2000000))
    keys=random.sample(lst,n)
    
    f = open("file1.txt",'wb')
    
    for i in range(0,n):
        pickle.dump(Record(keys[i]),f)
        
    f.close()

    f = open("file1.txt",'rb')
    Starting=int(input("Starting range:="))
    Ending= int(input("Ending point:="))
    pickle.load(f)
    size=f.tell()
    f.seek(0)
    f.seek((Starting-1)*size)
    
    for i in range(Starting,Ending+1):
        try:
            print(pickle.load(f))
        except:
            break
    f.close()

if __name__=="__main__":
    Records(n)
                  
