from rec import *

def SortRecords(fileName,n,blockSize):
    '''
    Objective: To sort records in blocks of given size and store them in new files.
    '''
    #Approach: Create an empty list and as many records as of blocksize and sort them.
    f = open(fileName,'rb')
    f1 = open(Records1,'wb')
    f2 = open(Records2,'wb')
    y=0
    c=0
    while y!=101:
        try:
            
            lst1=[]
            for i in range(0,blockSize):
                x=pickle.load(f)
                lst1.append(x)
            lst1=sorted(lst1,key=lambda Record:Record.generatekey())
            for i in lst1:
                pickle.dump(i,f1)
        except:
            break
        try:
            lst2=[]
            for i in range(0,blockSize):
                x=pickle.load(f)
                lst2.append(x)
            lst2=sorted(lst2,key=lambda Record:Record.generatekey())
            for i in lst2:
                pickle.dump(i,f2)
        except:
            break
    
    f.close()
    f1.close()
    f2.close()

    '''f1 = open("record1.txt",'rb')
    try :
        for i in range(0,52):
            x=pickle.load(f1)
            print(i)
            print(x)
    except:
        pass
    f1.close()


    f2 = open("record2.txt",'rb')
    try:
        for i in range(0,48):
            x=pickle.load(f2)
            print(i)
            print(x)
    except:
        pass
    f2.close()'''

    
    choose=int(input("Choose the file:"))

    if choose==1:
        f=open("Records1.txt",'rb')
    else:
        f=open("Records2.txt",'rb')

    print("Enter the range of record in file")
    start=int(input("Start of range: "))
    end=int(input("End ofrange: "))
    
    
    pickle.load(f)
    size=f.tell()
    f.seek(0)
    f.seek((start-1)*size)
    for i in range(start,end+1):
        try:
            x=pickle.load(f)
            print(i)
            print(x)
            c+=1
        except:
            print("Limit Exceed: No more Records")
            break
    
    f.close()

if __name__=="__main__":
    fileNmae='file1.txt'
    Records1='Records1.txt'
    Records2='Records2.txt'
    SortRecords(fileNmae,n,blockSize)    
