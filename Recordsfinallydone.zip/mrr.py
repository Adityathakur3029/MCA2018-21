from rec import *
def MergeRecords(Records1,Records2,n,blockSize):
    '''
    Objective: To merge the sorted records by comparing each record
               present in one file with the records of other file and create
               a block of double the size of given blocksize.           
    '''
    
    f3=open(Records3,'wb')
    f4=open(Records4,'wb')
    f1=open(Records1,'rb')
    f2=open(Records2,'rb')
    m=True
    flag=0
    while m:
        if flag==0:
            f=f3
            flag=1
        else:
            f=f4
            flag=0
        i=j=0
        try:
            
            while i<blockSize and j<blockSize:
            #try:
                t1=f1.tell()
                t2=f2.tell()
        
                x=pickle.load(f1)
                y=pickle.load(f2)
                if x.key<y.key:          
                    pickle.dump(x,f)
                    i+=1
                    f2.seek(t2)
                        
                    
                else:
                    pickle.dump(y,f)
                    j+=1
                    f1.seek(t1)
                
                        
        except:
            m=False
            break

        while i<blockSize:
            try:
                pickle.dump(x,f)
                i+=1
                if i<blockSize:
                    x=pickle.load(f1)
            except:
                break    
        while j<blockSize:
            try:
                pickle.dump(y,f)
                j+=1
                if j<blockSize:
    
                    y=pickle.load(f2)
            except:
                break

    f3.close()
    f4.close()
    f1.close()
    f2.close()

    f3=open("Records3.txt",'rb')
    for i in range (0,40):
        print(pickle.load(f3))
    print("Nxt File")    
       
    f4=open("Records4.txt",'rb')
    for i in range (0,40):
        print(pickle.load(f4))


if __name__=="__main__":
    
    Records1='Records1.txt'
    Records2='Records2.txt'
    Records3='Records3.txt'
    Records4='Records4.txt'
    MergeRecords(Records1,Records2,n,blockSize) 
